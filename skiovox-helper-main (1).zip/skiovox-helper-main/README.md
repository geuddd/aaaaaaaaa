<h1 align="center"> Skiovox Helper Minimal Light </h1>

> ### Forked from [here](https://github.com/bypassiwastaken/skiovox-helper) ( go star it )

![image](https://github.com/cloudirector/skiovox-helper/assets/143876484/d02b4833-7b09-4aae-ad88-d17b7ee083a8)
